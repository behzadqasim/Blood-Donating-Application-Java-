package blood_donating_system;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
public class Blood_donating_system {
 ArrayList<user> RegisteredUsers = new ArrayList<user>();
    public static void main(String[] args) {
        Blood_donating_system bld = new Blood_donating_system();
        bld.loadAllData();
        
       Login obj = new Login();
       obj.show();
       
    }
    public void loadAllData(){
        try {
            BufferedReader in = new BufferedReader(new FileReader("registeredusers.txt"));
            String str;

            while ((str = in.readLine())!= null) {
                String[] ar=str.split(",");
                user User = new user(ar[0],ar[1],ar[2],ar[3],ar[4],ar[5],ar[6],ar[7],ar[8]);
                RegisteredUsers.add(User);
            }
            in.close();
        } catch (IOException e) {
            System.out.println("File Read Error");
        }
    }
    public void saveAllData(){
        try {
            FileWriter myWriter = new FileWriter("registeredusers.txt");
            for (user User : RegisteredUsers) {
                myWriter.write(User.getName()+","+User.getAge()+","+User.getAddress()+","+User.getBloodtype()+","+User.getHealth()+","+User.getCity()+","+User.getPhone()+","+User.getUsername()+","+User.getPassword()+"\n");
            }
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.while creating Account");
        }

    }
}
