/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blood_donating_system;

public class user {
    String name;
    String age;
    String address;
    String bloodtype;
    String health;
    String city;
    String phone;
    String username;
    String password;

    public user(String name, String age, String address, String bloodtype, String health, String city,String phone, String username, String password) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.bloodtype = bloodtype;
        this.health = health;
        this.city = city;
        this.phone = phone;
        this.username = username;
        this.password = password;
    }

   public user(String name, String age, String address, String bloodtype, String health, String city,String phone) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.bloodtype = bloodtype;
        this.health = health;
        this.city = city;
        this.phone = phone;
    }
    public user(String name,String bloodtype,String city,String phone) {
        this.name = name;
        this.bloodtype = bloodtype;
        this.city = city;
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public String getBloodtype() {
        return bloodtype;
    }

    public String getAge() {
        return age;
    }

    public String getHealth() {
        return health;
    }

    public String getCity() {
        return city;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public String getPhone() {
        return phone;
    }
    
    
}
